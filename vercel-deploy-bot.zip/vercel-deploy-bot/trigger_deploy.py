
import os
import requests

VERCEL_TOKEN = os.getenv("VERCEL_TOKEN")
PROJECT_NAME = os.getenv("VERCEL_PROJECT_NAME")

def trigger():
    response = requests.post(
        f"https://api.vercel.com/v13/deployments",
        headers={
            "Authorization": f"Bearer {VERCEL_TOKEN}",
            "Content-Type": "application/json",
        },
        json={
            "name": PROJECT_NAME,
            "target": "production",
            "gitSource": {
                "type": "github",
                "repoId": os.getenv("GITHUB_REPO_ID"),
                "ref": "main"
            }
        }
    )
    print("Deploy triggered:", response.json())

if __name__ == "__main__":
    trigger()
