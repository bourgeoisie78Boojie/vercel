
import os
import requests

VERCEL_TOKEN = os.getenv("VERCEL_TOKEN")
PROJECT_ID = os.getenv("VERCEL_PROJECT_ID")
ORG_ID = os.getenv("VERCEL_ORG_ID")
ENV_VARS = {
    "OPENAI_API_KEY": os.getenv("OPENAI_API_KEY"),
    "GEMINI_API_KEY": os.getenv("GEMINI_API_KEY"),
    "CLAUDE_API_KEY": os.getenv("CLAUDE_API_KEY"),
    "SUPABASE_URL": os.getenv("SUPABASE_URL"),
    "SUPABASE_ANON_KEY": os.getenv("SUPABASE_ANON_KEY"),
    "STRIPE_LIVE_KEY": os.getenv("STRIPE_LIVE_KEY"),
    "TELEGRAM_BOT_TOKEN": os.getenv("TELEGRAM_BOT_TOKEN"),
    "WHATSAPP_NUMBER": os.getenv("WHATSAPP_NUMBER"),
}

def inject():
    for key, value in ENV_VARS.items():
        response = requests.post(
            f"https://api.vercel.com/v10/projects/{PROJECT_ID}/env",
            headers={"Authorization": f"Bearer {VERCEL_TOKEN}"},
            json={
                "key": key,
                "value": value,
                "type": "encrypted",
                "target": ["production"]
            }
        )
        print(f"{key}: {response.status_code}")

if __name__ == "__main__":
    inject()
